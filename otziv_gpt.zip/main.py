import pandas as pd
from tqdm import tqdm
from openai import OpenAI
from config import OPENAI_API_KEY

# Инициализация клиента OpenAI
client = OpenAI(api_key=OPENAI_API_KEY)

# Загрузка данных
df = pd.read_csv('data.csv', encoding='utf-8')

# Функция для обработки отзывов по бренду с помощью GPT
def process_brand_reviews(brand, specialization, reviews):
    prompt = f"""
    Бренд: {brand}
    Специализация: {specialization}
    Отзывы:
    {reviews}

    Пожалуйста, проанализируйте эти отзывы и предоставьте:
    1. Краткую выжимку ключевых моментов для этого бренда
    2. Общее резюме о бренде на основе отзывов
    """

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )

    return response.choices[0].message.content

# Обработка данных по каждому бренду
results = []
for brand in tqdm(df['Brand'].unique()):
    brand_data = df[df['Brand'] == brand]
    specialization = brand_data['Specialization'].iloc[0]
    reviews = "\n".join(brand_data['Comment'].tolist())
    
    summary = process_brand_reviews(brand, specialization, reviews)
    avg_score = brand_data['Score'].mean()
    
    results.append({
        'Brand': brand,
        'Specialization': specialization,
        'Average Score': avg_score,
        'Summary': summary
    })

# Создание DataFrame с результатами
result_df = pd.DataFrame(results)

# Сохранение результатов в новый CSV файл
result_df.to_csv('processed_reviews_by_brand.csv', index=False)

print("Обработка завершена. Результаты сохранены в 'processed_reviews_by_brand.csv'")